
namespace DVDNameSpace {
  export class Main {
    
  }
  $(document).ready(function () {
    const mainSection = $('#mainSection');
    // const page2 = $('#page2');
    // const page3 = $('#page3');
    // const page4 = $('#page4');
    // const page5 = $('#page5');
    const main_div = $('<div>').attr('id', 'main_div').addClass('pages');
    const about_div = $('<div>').attr('id', 'about_div').addClass('pages');
    const contact_div = $('<div>').attr('id', 'contact_div').addClass('pages');
    const gallery_div = $('<div>').attr('id', 'gallery_div').addClass('pages');

    $('#main_menu_btn').click(openDiv);
    $('#about_menu_btn').click(openDiv);
    $('#contact_menu_btn').click(openDiv);
    $('#gallery_menu_btn').click(openDiv);

    console.log("Jquery");

    console.log("About to execute a typescript command");
    let dvd1 = new DVD();
    console.log(" The dvd 3");
    dvd1.setPrice(340);
    dvd1.setName("Lion King");
    dvd1.displayDVD();

    const head1 = $('<h1>Page1a</h1>');
    const label1 = $('<label>').text('Name').addClass('label-style');
    const label2 = $('<label>').text('Price').addClass('label-style');
    const input1 = $('<input>');
    const input2 = $('<input>');
    const button = $('input[type=submit]')
      .addClass('btn btn-danger')
      .click(btnClick);
    const form = $('<form>');
    form.append(label1);
    form.append(input1);
    form.append('<br>');
    form.append(label2);
    form.append(input2);
    form.append('<br>');
    form.append(button);
    main_div.append(head1);
    main_div.append(form).addClass('container-fluid');

    const head2 = $('<h1>Page 2</h1>');
    const p2 = $('<p> Content for page Two </p>');
    // const div2 = $('<div>');
    about_div.append(head2);
    about_div.append(p2);

    const head3 = $('<h1>Page 3 </h1>');
    const p3 = $('<p> Content for page Three </p>');
    // const div2 = $('<div>');
    contact_div.append(head3);
    contact_div.append(p3);

    const ur = "http://mmedia.cput.ac.za/MUT370S_live/api/rest.php/user_t";
    $.get(ur, function(data: any) {
      console.log(data);
        contact_div.append(data);
    });
    contact_div.append("<h1>END</h1>");


    const head4 = $('<h1>Page 4 </h1>');
    const p4 = $('<p> Content for page Four </p>');
    // const div2 = $('<div>');
    gallery_div.append(head4);
    gallery_div.append(p4);

    function btnClick() {
      confirm("Are you sure  you want to add this DVD!");
      window.location.href = "mailto:sydwell@gmail.com:testing 123";
    }

    /**
     * Use jquery to " OPEN " a page
     */
    function openDiv(element: JQueryEventObject) {
    //  console.log(" element.target ");
   //   console.log(element.target.id);
      const targetId = element.target.id;
      $(".menuLi").removeClass('active');
      $(".pages").detach();

      $("#" + targetId).parent().addClass('active');

      switch (targetId) {
        case "main_menu_btn": mainSection.append(main_div); break;
        case "about_menu_btn": mainSection.append(about_div); break;
        case "contact_menu_btn": mainSection.append(contact_div); break;
        case "gallery_menu_btn": mainSection.append(gallery_div); break;
        default: console.log(" Targetted div " + targetId + " not found ");
      }

    }


  }); // End of document.ready

}
