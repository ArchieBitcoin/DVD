namespace DVDNameSpace {
    export class About {
        
    }

}